package src;
import java.util.Arrays;
import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JTable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Combo;

public class AssignmentSolver implements MouseListener, org.eclipse.swt.events.MouseListener{

	protected Shell shell;
	private Text text;
	private Text text_1;
	private Composite composite_1;
	private Table table;
	private TableColumn tblclmnNewColumn;
	private Label lblEnterValue;
	private Text text_2;
	private Button btnOk;
	private int count = 1;
	private int c = 0;
	private int c2 = 0;
	private int r = 0;
	private int[] arr = new int[20];
	private int[][] dataMat;
	private Button btnConfirm;
	private int rows;
	private int columns;
	private Label lblNewLabel_1;
	String[] items = new String[] { "A", "B" };
	Combo combo;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			AssignmentSolver window = new AssignmentSolver();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(450, 652);
		shell.setText("SWT Application");
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBounds(0, 0, 424, 73);
		
		Label lblEnterOf = new Label(composite, SWT.NONE);
		lblEnterOf.setBounds(26, 10, 88, 15);
		lblEnterOf.setText("Enter # of Rows:");
		
		text = new Text(composite, SWT.BORDER);
		text.setBounds(120, 7, 76, 21);
		
		Label lblNewLabel = new Label(composite, SWT.NONE);
		lblNewLabel.setBounds(213, 10, 104, 15);
		lblNewLabel.setText("Enter # of Columns:");
		
		text_1 = new Text(composite, SWT.BORDER);
		text_1.setBounds(323, 7, 76, 21);
		
		btnConfirm = new Button(composite, SWT.NONE);
		btnConfirm.setBounds(164, 38, 88, 25);
		btnConfirm.setText("Confirm");
		
		composite_1 = new Composite(shell, SWT.NONE);
		composite_1.setBounds(10, 79, 414, 172);
		
		table = new Table(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		table.setBounds(0, 0, 414, 172);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		lblEnterValue = new Label(shell, SWT.NONE);
		lblEnterValue.setText("Enter Value {}:");
		lblEnterValue.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblEnterValue.setBounds(10, 323, 121, 23);
//		lblEnterValue.setText("Enter Value "+count+":");
		
		text_2 = new Text(shell, SWT.BORDER);
		text_2.setBounds(137, 325, 206, 21);
		
		btnOk = new Button(shell, SWT.NONE);
		btnOk.setBounds(349, 323, 75, 25);
		btnOk.setText("Ok");
		
		Button btnNewButton = new Button(shell, SWT.NONE);
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnNewButton.setBounds(163, 371, 98, 42);
		btnNewButton.setText("Calculate");
		
		lblNewLabel_1 = new Label(shell, SWT.NONE);
		lblNewLabel_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
		lblNewLabel_1.setBounds(10, 458, 414, 146);
		
		Label lblResult = new Label(shell, SWT.NONE);
		lblResult.setFont(SWTResourceManager.getFont("Segoe UI", 15, SWT.NORMAL));
		lblResult.setBounds(183, 419, 67, 33);
		lblResult.setText("Result:");
		
		Label lblCaseType = new Label(shell, SWT.NONE);
		lblCaseType.setBounds(10, 269, 121, 25);
		lblCaseType.setFont(SWTResourceManager.getFont("Segoe UI", 12, SWT.NORMAL));
		lblCaseType.setText("Case Type");
		combo = new Combo(shell, SWT.NONE);
		combo.setBounds(137, 271, 287, 23);
		
		 
		combo.setItems(items);
		
		btnConfirm.addMouseListener(this);
		btnOk.addMouseListener(this);
		btnNewButton.addMouseListener(this);

	}

	@Override
	public void mouseDoubleClick(org.eclipse.swt.events.MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDown(org.eclipse.swt.events.MouseEvent e) {
		// TODO Auto-generated method stub
		String text_one = text.getText();
		String text_two = text_1.getText();
		int rows =  Integer.parseInt(text_one);
		int columns =  Integer.parseInt(text_two);
//		lblEnterValue.setText("Enter Value "+"{"+count+"}"+':');
		if(e.toString().contains("Ok")) {
			count = count + 1;
			
			System.out.println("count equalls = "+count);
			if(count-1 <= rows*columns) {
				if(c <= rows-1) {
					c2 = c + c2;
					arr[c] = Integer.parseInt(text_2.getText());
					dataMat[r][c] = arr[c];
					for (int i = 0; i < dataMat.length; i++) { 
			            for (int j = 0; j < dataMat[i].length; j++) { 
			                System.out.print(dataMat[i][j] + " "); 
			            } 
			  
			            System.out.println(); 
			        } 
					c = c + 1;
					System.out.println("C equalls = "+c);
					
					System.out.println("C2 equalls = "+c2);
					
					if(c > columns-1) {
						TableItem tableItemX = new TableItem(table, SWT.NONE);
						for(int i=0;i<columns;i++) {
							int num = arr[i];
							tableItemX.setText(i,Integer.toString(arr[i]));
						}
						
						c = 0;
						r = r + 1;
					}
				}else {
					c = 0;
//					lblEnterValue.setText("Thanks");
				}
				
			}else {
			}
			String finishText;
			if(count <= rows*columns) {
				finishText = "Enter Value "+"{"+count+"}"+':';
			}else {
				finishText = "Thanks!";
				text_2.setVisible(false);
			}
			lblEnterValue.setText(finishText);
			text_2.setText("");
			
			
		}else if (e.toString().contains("Confirm")) {
//			System.out.println("x");
			rows =  Integer.parseInt(text_one);
			columns =  Integer.parseInt(text_two);
			dataMat = new int[rows][columns];
			btnConfirm.setVisible(false);
			String[] columnNames = new String[columns];
			
			for(int i = 0;i<columns;i++) {
				columnNames[i] = "Column "+(i+1);
//				System.out.println(i);
			}
			for(int i = 0;i<columns;i++) {
				tblclmnNewColumn = new TableColumn(table, SWT.NONE);
				tblclmnNewColumn.setWidth(100);
				tblclmnNewColumn.setText(columnNames[i]);
			}
//			System.out.println(text_one+"x"+text_two);
			lblEnterValue.setText("Enter Value "+"{"+count+"}"+':');
		}
		else if (e.toString().contains("Calculate")) {
//			String[] caseType = combo.getItems();
			int idx = combo.getSelectionIndex();
			String caseType = combo.getItem(idx);
			Assignment4 assignmentObj = new Assignment4(dataMat,caseType.charAt(0));
			String result = assignmentObj.getResultA();
			lblNewLabel_1.setText(result);
		}
		
		
//		for(int i=0;i<rows*columns;i++) {
//			lblEnterValue.setText("Enter Value "+i+':');
//		}
//		
		
//		table  = new JTable(data, columnNames);
//		composite_1.add
		
	}

	@Override
	public void mouseUp(org.eclipse.swt.events.MouseEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}




