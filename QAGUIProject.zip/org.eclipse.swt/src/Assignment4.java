
package src;
import java.util.Arrays;
import java.util.Scanner;
import java.util.LinkedHashSet;
import java.util.Set;
public class Assignment4 {

    private int[][] dataMat;
	Assignment4(int[][] dataMat,char problemType) {
		this.dataMat = dataMat;
//        Scanner input=new Scanner(System.in);
//                System.out.println(" if the Matrix is Square press A, if Rows is more than columns press B ");
//               char n=input.next().charAt(0);
//        switch (problemType){
//               case ('A'):
               
//        System.out.println(" Please enter no of rows and columns ");
        
//        int row=input.nextInt();
//        int columns = input.nextInt();
//        System.out.println(" Please enter the Matrix   <row wise>\"); ");

      // the problem is written in the form of a matrix
      
//   int[][] dataMatrix  = new int [row][columns];
  
//        for (int i = 0; i < dataMat.length; i++)
//        {
//            for (int j = 0; j < dataMat[i].length; j++)
//            {
//            	dataMat[i][j] = input.nextInt();
//            }
//        }

      
      
    
//               case ('B'):    
//                          System.out.println(" You should enter dummy Row to make it Square Matrix ");     
//        System.out.println(" Please enter no of rows and columns ");
//        
//        int rows=input.nextInt();
//        int column = input.nextInt();
//        System.out.println(" Please enter the Matrix   <row wise>\"); ");

           
     
//   int[][] x  = new int [rows][column];
//  
//        for (int i = 0; i < rows; i++)
//        {
//            for (int j = 0; j < column; j++)
//            {
//               x [i][j] = input.nextInt();
//            }
//        }
//      HungarianAlgorithm has = new HungarianAlgorithm(dataMat);
//           int[][] assignmen = has.findOptimalAssignment();
//               
//      if (assignmen.length > 0) {
////         print assignment
//        for (int i = 0; i < assignmen.length; i++) {
//          System.out.print("Job" + assignmen[i][0] + " => Person" + assignmen[i][1] + " (" + dataMat[assignmen[i][0]][assignmen[i][1]] + ")");
////          System.out.println();
////          System.out.println(assignmen[i]);
//        }
//      } else {
//        System.out.println("no assignment found!");
//      } break;
      
               
               
        
    }
	public String getResultA() {
		String result = "\n";
		HungarianAlgorithm ha = new HungarianAlgorithm(this.dataMat);
	     
	      int[][] assignment = ha.findOptimalAssignment();

	      if (assignment.length > 0) {
	        // print assignment
	        for (int i = 0; i < assignment.length; i++) {
	          result += "\t\t\tJob" + (assignment[i][0]+1) + " => Person" + (assignment[i][1]+1) + " (" + (dataMat[assignment[i][0]][assignment[i][1]]+1) + ")\n";
	         
	        }
//	     System.out.println("  ");
	     } else {
	        System.out.println("no assignment found!");
	      }
		
		return result;
	}
	
	
	public String getResultB() {
		String result = "";
		HungarianAlgorithm ha = new HungarianAlgorithm(this.dataMat);
	     
	      int[][] assignment = ha.findOptimalAssignment();
	      HungarianAlgorithm has = new HungarianAlgorithm(dataMat);
          int[][] assignmen = has.findOptimalAssignment();
              
     if (assignmen.length > 0) {
//        print assignment
       for (int i = 0; i < assignmen.length; i++) {
         System.out.print("Job" + (assignmen[i][0]+1) + " => Person" + assignmen[i][1]+1 + " (" + dataMat[assignmen[i][0]][assignmen[i][1]]+1 + ")");
//         System.out.println();
//         System.out.println(assignmen[i]);
       }
     } else {
       System.out.println("no assignment found!");
     }
	      
		
		return result;
	}
}
